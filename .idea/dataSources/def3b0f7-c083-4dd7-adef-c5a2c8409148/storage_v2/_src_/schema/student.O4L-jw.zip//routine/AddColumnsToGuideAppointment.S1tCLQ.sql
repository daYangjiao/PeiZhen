create
    definer = root@localhost procedure AddColumnsToGuideAppointment()
BEGIN
    -- 检查并添加 hospital_name
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_appointment' AND COLUMN_NAME = 'hospital_name') THEN
        ALTER TABLE guide_appointment ADD COLUMN hospital_name VARCHAR(100) DEFAULT '' NOT NULL COMMENT '医院名称' AFTER id;
    END IF;
    
    -- 检查并添加 service_date（给默认值，避免已有数据报错）
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_appointment' AND COLUMN_NAME = 'service_date') THEN
        ALTER TABLE guide_appointment ADD COLUMN service_date DATE DEFAULT '1970-01-01' NOT NULL COMMENT '服务日期' AFTER hospital_name;
    END IF;
    
    -- 检查并添加 service_start_time
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_appointment' AND COLUMN_NAME = 'service_start_time') THEN
        ALTER TABLE guide_appointment ADD COLUMN service_start_time TIME DEFAULT '00:00:00' NOT NULL COMMENT '服务开始时间' AFTER service_date;
    END IF;
    
    -- 检查并添加 service_end_time
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_appointment' AND COLUMN_NAME = 'service_end_time') THEN
        ALTER TABLE guide_appointment ADD COLUMN service_end_time TIME DEFAULT '00:00:00' NOT NULL COMMENT '服务结束时间' AFTER service_start_time;
    END IF;
    
    -- 检查并添加 service_type_number
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_appointment' AND COLUMN_NAME = 'service_type_number') THEN
        ALTER TABLE guide_appointment ADD COLUMN service_type_number INT DEFAULT 0 NOT NULL COMMENT '服务类型编号' AFTER service_end_time;
    END IF;
    
    -- 检查并添加 symptoms（JSON类型，允许为空）
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_appointment' AND COLUMN_NAME = 'symptoms') THEN
        ALTER TABLE guide_appointment ADD COLUMN symptoms JSON COMMENT '症状列表' AFTER service_type_number;
    END IF;
    
    -- 检查并添加 other_requirement
    IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'guide_appointment' AND COLUMN_NAME = 'other_requirement') THEN
        ALTER TABLE guide_appointment ADD COLUMN other_requirement TEXT COMMENT '其他需求' AFTER symptoms;
    END IF;
END;

